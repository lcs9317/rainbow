#include "locationinfo.h"
#include "mainwindow.h"

LocationInfo::LocationInfo(QObject *parent) : QObject(parent)
{
    m_win = (MainWindow *)parent;
}

// html의 javascript로부터 호출될 시그널 함수
// public영역이 아닌 slots 영역에 정의해야함을 주의!!!
void LocationInfo::sltLocationChanged(float x, float y, int index)
{
    switch(index){
    case 1:
        m_location1.setX(x);
        m_location1.setY(y);
        break;
    case 2:
        m_location2.setX(x);
        m_location2.setY(y);
        break;
    }
    m_win->changeLocation(index);
}

