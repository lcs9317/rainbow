#include <QWidget>

// QObject를 직/간접적으로 상속받아야함
class Widget : public QWidget {

  // Q_OBJECT를 명시해줘야함
  Q_OBJECT

public:
  Widget(QWidget *parent = 0);
  ~Widget();

// 슬롯은 접근지정자+slots안에다가 구현했는가
public slots:
  void slotQuit();

};
