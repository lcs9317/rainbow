#ifndef LOCATIONINFO_H
#define LOCATIONINFO_H

#include <QObject>
#include <QPointF>

class MainWindow;

class LocationInfo : public QObject
{
    Q_OBJECT
public:
    explicit LocationInfo(QObject *parent = 0);
    QPointF m_location1;
    QPointF m_location2;

private:
    MainWindow *m_win;

public slots:
    // html의 javascript로부터 호출될 시그널 함수
    // public영역이 아닌 slots 영역에 정의해야함을 주의!!!
    void sltLocationChanged(float x, float y, int index);
};

#endif // LOCATIONINFO_H
