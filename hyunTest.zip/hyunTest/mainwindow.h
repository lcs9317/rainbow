#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QWebView>
#include <QWebPage>
#include <QWebFrame>
#include <QDebug>
#include "locationinfo.h"

namespace Ui {
class MainWindow;
}

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = 0);
    ~MainWindow();

    void changeLocation(int index);

private:
    Ui::MainWindow *ui;

    QWebView *m_view1;
    QWebView *m_view2;

    LocationInfo *m_locInfo;

public slots:
    void sltAddObject();

};

#endif // MAINWINDOW_H
