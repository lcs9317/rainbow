Widget::Widget(QWidget *parent) : QWidget(parent) {

  QLabel *label = new QLabel("<font color=blue>Hello Qt!</font>", this);
  label->setGeometry(10,50,75,35);

  connect(quit, SIGNAL(clicked()), this, SLOT(slotQuit()));
}

void Widget::slotQuit() {

  qDebug("slotQuit");
  qApp->quit();
}
