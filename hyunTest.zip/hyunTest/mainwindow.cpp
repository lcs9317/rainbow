#include "mainwindow.h"
#include "ui_mainwindow.h"

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);

    // HTML의 javascript로부터 데이터를 읽어올 오브젝트
    m_locInfo = new LocationInfo(this);

    /** Case 1,WebVew 생성(From에 WebView를 추가하고 해당 WebView를 받아오는 경우 **/
    m_view1 = ui->webView; // ui로부터 WebView를 받아옴
    m_view1->setUrl(QUrl("qrc:/test1.html")); // WebView에 출력할 html파일 설정
    // 오브젝트를 바로 주입하지 않고, signal을 받은 후 주입함
    connect(m_view1->page()->mainFrame(),SIGNAL(javaScriptWindowObjectCleared())
            ,this,SLOT(sltAddObject()));    //

    /** Case 2,WebVew를 직접 생성하는 경우 **/
    m_view2 = new QWebView(this);   // WebView 생성
    m_view2->setUrl(QUrl("qrc:/test2.html"));   // WebView에 출력할 html파일 설정
    m_view2->setGeometry(430,15,400,300);   // WebView의 위치와 크기 설정
    m_view2->page()->mainFrame()->addToJavaScriptWindowObject("locInfo",m_locInfo); // 오브젝트를 직접 바로 주입
    // WebView 출력, MainWindow내에서 생성되었기 때문에 show() 호출 없이도 바로 출력됨
    // 윈도우 없이 콘솔응용에서 바로 WebView를 생성하는 경우에는 show()를 호출해야 출력됨
    //m_view2->show();
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::changeLocation(int index)
{
    switch(index){
    case 1:
        ui->leLat01->setText(QString::number(m_locInfo->m_location1.rx()));
        ui->leLng01->setText(QString::number(m_locInfo->m_location1.ry()));
        break;
    case 2:
        ui->leLat02->setText(QString::number(m_locInfo->m_location2.rx()));
        ui->leLng02->setText(QString::number(m_locInfo->m_location2.ry()));
        break;
    }
}

void MainWindow::sltAddObject()
{
    m_view1->page()->mainFrame()->addToJavaScriptWindowObject("locInfo",m_locInfo);
}
